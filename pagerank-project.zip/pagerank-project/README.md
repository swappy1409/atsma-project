# PageRank on three networks (ATSMA Web Analytics project)

## Files
- `PageRank_Web_Analytics.ipynb`: the full project notebook (theory, from-scratch PageRank, NetworkX check, all 3 datasets, charts, conclusions)
- `pagerank_web_analytics.py`: the same code as a plain script (cells marked with `# %%`)
- `outputs/`: charts and tables. Karate results are already there; VIT-AP and Wikipedia files appear after you run the notebook.
- `requirements.txt`

## Run it (about 10 minutes)
1. `pip install -r requirements.txt`
2. Wikipedia data: download the zip from https://www.kaggle.com/datasets/kutayahin/wikipedia-link-graph-100k and put it (zipped or unzipped) in `data/wikipedia/`.
   Or skip this: the notebook tries `kagglehub` automatically (needs a Kaggle login/API token locally; works out of the box on Kaggle and Colab).
3. Open the notebook in Jupyter / VS Code / Colab and choose **Run All**.
   - The VIT-AP crawl takes ~3-5 minutes (300 pages, 0.5 s pause between requests, obeys robots.txt). It is cached in `data/vitap_edges.csv`, so later runs are instant.
   - Wikipedia (~28.9M links) needs ~2-4 GB RAM. On a small laptop set `MAX_EDGES = 5_000_000` in the Wikipedia section, or run on Colab/Kaggle.
4. Everything for the slides is saved in `outputs/` (PNG charts, CSV top-k tables, `results.json`).

## Colab
Upload the notebook, run all. For Wikipedia either upload the Kaggle zip into `data/wikipedia/` or let `kagglehub` download it.
